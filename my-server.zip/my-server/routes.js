import { aboutPage, homePage, notFoundPage, productsPage } from "./views.js"

export function route(req, res) {
    if(req.method === "GET" && req.url === "/home"){
        res.writeHead(200, {"Content-type": "text/html"})
        res.end(homePage())
        return
    }
    if(req.method === "GET" && req.url === "/products"){
        res.writeHead(200, {"Content-type": "text/html"})
        res.end(productsPage())
        return
    }
    if(req.method === "GET" && req.url === "/about"){
        res.writeHead(200, {"Content-type": "text/html"})
        res.end(aboutPage())
        return
    }
    res.writeHead(404, {"Content-Type": "text/html"})
    res.end(notFoundPage())
}