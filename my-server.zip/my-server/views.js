//MOCK -> código que simula o dado real...
const products =[
  { name: "Keybord", price: 150},
  { name: "Mouse", price: 80},
  { name: "Monitor", price: 900},
]
function layout(title, content) {
  return `
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  </head>
  <body>
  <nav> 
  <a href="/home">Home</a>
  <a href="/products">Products</a>
  <a href="/about">About</a>
  </nav> 
  ${content}
  </body>
  </html>
  
  `
}

export function homePage() {
  return layout("Home","<h1>Welcome to the store</h1>")
}
export function aboutPage() {
  return layout("About","<h1>About Us</h1>")
}
export function notFoundPage() {
  return layout("Not Found","<h1>Page Not Found</h1>")
}


export function productsPage() {

  const rows = products.map((p) => `<tr>
  <td>${p.name}</td>
  <td>${p.price}</td>
    </tr>`)
    .join(" ")
  return layout("Products",`
    <h1>Products</h1> 
    <table>
    <tr>
    <th>Product</th> )
    <th>Price</th>
    <tr>
    ${rows}
    </table> `)
}

















/*const produtos = [
  { nome: 'Teclado', preco: 150 },
  { nome: 'Mouse', preco: 80 },
  { nome: 'Monitor', preco: 900 },
];

function layout(titulo, conteudo) {
  return `
    <!DOCTYPE html>
    <html lang="pt-br">
      <head><meta charset="UTF-8"><title>${titulo}</title></head>
      <body>
        <nav>
          <a href="/">Início</a>
          <a href="/produtos">Produtos</a>
          <a href="/sobre">Sobre</a>
        </nav>
        ${conteudo}
      </body>
    </html>
  `;
}

export function paginaInicial() {
  return layout('Início', '<h1>Bem-vindo à loja</h1>');
}

export function paginaProdutos() {
  const linhas = produtos
    .map((p) => `<tr><td>${p.nome}</td><td>R$ ${p.preco}</td></tr>`)
    .join('');

  return layout('Produtos', `
    <h1>Produtos</h1>
    <table>
      <tr><th>Produto</th><th>Preço</th></tr>
      ${linhas}
    </table>
  `);
}

export function paginaSobre() {
  return layout('Sobre', '<h1>Sobre nós</h1>');
}

export function paginaNaoEncontrada() {
  return layout('Não encontrado', '<h1>Página não encontrada</h1>');
}*/