import {
  paginaInicial,
  paginaProdutos,
  paginaSobre,
  paginaNaoEncontrada,
} from './views.js';

export function rotear(requisicao, resposta) {
  if (requisicao.method === 'GET' && requisicao.url === '/') {
    resposta.writeHead(200, { 'Content-Type': 'text/html' });
    resposta.end(paginaInicial());
    return;
  }

  if (requisicao.method === 'GET' && requisicao.url === '/produtos') {
    resposta.writeHead(200, { 'Content-Type': 'text/html' });
    resposta.end(paginaProdutos());
    return;
  }

  if (requisicao.method === 'GET' && requisicao.url === '/sobre') {
    resposta.writeHead(200, { 'Content-Type': 'text/html' });
    resposta.end(paginaSobre());
    return;
  }

  resposta.writeHead(404, { 'Content-Type': 'text/html' });
  resposta.end(paginaNaoEncontrada());
}